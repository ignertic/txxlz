#__main__.py









def main():
	"""Execute any function"""
	print("Hello There!")
	

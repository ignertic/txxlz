#Txxlz
##Python Small Tools
####A collection of miscellaneous tools
#####Currently Avaliable :
*Public IP checker*


>pip install txxlz

```python
>>> import txxlz
>>> addr = txxlz.ip.current_adress()
>>> print(add)
```

##Feel Free to Contribute
If you have any small light Python tools feel free to contribute..
